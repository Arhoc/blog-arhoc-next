# SpotifyPremium
 Desktop MOD (ad free)



## Table of contents
* [About](#about)
* [Prerequisite](#prerequisite)
* [Installation](#installation)


## About
Spotify-Desktop_v1.1.22.633
Modified version of Spotify, removes all on screen advertisements and advertisements between songs.

![image](https://user-images.githubusercontent.com/56351738/151934393-70cde3db-62f7-48d7-8250-dbb2d741226f.png)

## Prerequisite
```Uninstall any previous version of Spotify already installed on your Desktop```

## Installation
```
 Extract "Spotify Crack by Zuptil.zip"
 Open "Spotify-Desktop_v1.1.22.633" folder
 Run "SpotifyFullSetup_v1.1.22.633.exe" and install Spotify
 Once Spotify opens proceed to close the application
 Run "SpotifyPatch.bat" 
 Open Spotify and login
 Enjoy ad-free music and podcasts
 ```

